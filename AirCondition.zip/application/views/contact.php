	<div id="body">
		<div class="content">
			<div class="article">
				<h3>contact us</h3>
				<p>
					This website template has been designed by <a href="http://www.freewebsitetemplates.com/">Free Website Templates</a> for you, for free. You can replace all this text with your own text. You can remove any link to our website from this website template, you're free to use this website template without linking back to us. If you're having problems editing this website template, then don't hesitate to ask for help on the <a href="http://www.freewebsitetemplates.com/forums/">Forums</a>.
				</p>
				<ul>
					<li>
						<span>Address :</span> 7177 Saint Michael Drive, Los Angeles, CA 90048, United States
					</li>
					<li>
						<span>Office Phone Number :</span> (864) 232-3553
					</li>
					<li>
						<span>Fax Number :</span> (864) 232-4160
					</li>
					<li>
						<span>Email :</span> <a href="http://www.freewebsitetemplates.com/misc/contact">info@zizurz.com</a>
					</li>
				</ul>
			</div>
		</div>
	</div>
