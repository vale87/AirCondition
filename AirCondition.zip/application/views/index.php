
    
    <div id="body">
                         
<div id="myCarousel" class="carousel slide carousel-fade" data-ride="carousel">


    <!-- Carousel items -->
    <div class="carousel-inner">

      <!-- Slide 1 : Active -->
      <div class="item active">
        <img src="https://cl.ly/image/3J45082V2c1L/banner_01.jpg" alt="">
        <div class="carousel-caption">
          <h3>Slide 1</h3>
          <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur et.</p>
        </div><!-- /.carousel-caption -->
      </div><!-- /Slide1 -->

      <!-- Slide 2 -->
      <div class="item ">
        <img src="https://cl.ly/image/2J0z1t033B25/banner_02.jpg" alt="">
        <div class="carousel-caption">
          <h3>Slide 2</h3>
          <p>Etiam porta sem malesuada magna mollis euismod.</p>
        </div><!-- /.carousel-caption -->
      </div><!-- /Slide2 -->

      <!-- Slide 3 -->
      <div class="item ">
        <img src="https://cl.ly/image/1a3i3k0F3B3h/banner_03.jpg" alt="">
        <div class="carousel-caption">
          <h3>Slide 3</h3>
          <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam.</p>
        </div><!-- /.carousel-caption -->
      </div><!-- /Slide3 -->

      <!-- Slide 4 -->
      <div class="item ">
        <img src="https://cl.ly/image/1n0A2k0Z111n/banner_04.jpg" alt="">
        <div class="carousel-caption">
          <h3>Slide 4</h3>
          <p>Pellentesque ornare sem lacinia quam venenatis vestibulum.</p>
        </div><!-- /.carousel-caption -->
      </div><!-- /Slide4 -->

    </div><!-- /.carousel-inner -->

  </div><!-- /#myCarousel -->

  <div class="services">
    <div class="content"> 
      <h2>OUR SERVICES</h2>
      <div class="row between-xs center-xs">
        <div class="col-xs">
          <h3>Maintenance</h3>
          <a href="hairstyle.html"><div id="divimg"><img src="<?php echo base_url(); ?>/assets/images/hairstyle1.jpg" alt=""></div></a>
          <p>We service, repair, and replace makes & models of ALL brands! Our experienced and knowledgeable technicians inspect your systems to make sure everything is in working order</p>
          <span> Read more > </span>  
        </div>
        <div class="col-xs">
          <h3>Air Conditioning</h3>
          <a href="hairstyle.html"><div id="divimg"><img src="<?php echo base_url(); ?>/assets/images/hairstyle2.jpg" alt=""></div></a>
          <p>We can install, repair, or maintain your commercial air conditioning system.  Our technicians move quickly to identify and repair the problem, or even replace the system if necessary</p>
          <span> Read more > </span>  
        </div>
        <div class="col-xs">
          <h3>Indoor Air</h3>
          <a href="hairstyle.html"><div id="divimg"><img src="<?php echo base_url(); ?>/assets/images/hairstyle3.jpg" alt=""></div></a>
          <p>At TemperaturePro, we believe that the air quality in your home or business is just as important as the temperature, so we offer a wide variety of products and services that work to improve the quality of air that you breathe.</p>
          <span> Read more > </span>  
        </div>
        <div class="col-xs">
          <h3>Repairs</h3>
          <a href="hairstyle.html"><div id="divimg"><img src="<?php echo base_url(); ?>/assets/images/hairstyle4.jpg" alt=""></div></a>
          <p>Our FULL-SERVICE  property management, air conditioning, heating, and refrigeration service package has many benefits for property management professionals.</p>
          <span> Read more > </span>  
        </div>
      </div>
    </div>
  </div>
    <div class="about">
       <div class="content"> 
          <h2>about us</h2>
          <p>
          We started TemperaturePro Tampa Bay because we know how brutal the Florida heat & humidity can be. We don’t want to see anyone suffer, so that’s why we’re here! We want to deliver you COOL relief FAST!
We value speed and customer service as much as you value feeling comfortable in your own home. We proudly provide healthy air and comfort through trusted, quality HVAC sales & service for residential & light commercial spaces in the Tampa Bay Region.
          <p>
          </div>
    </div>
      <div class="ofert">
        
    </div>
  </div>

        

