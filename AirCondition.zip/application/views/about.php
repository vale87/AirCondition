   
    <div id="about">
       <div class="content wow fadeInDown"> 
          <h2>NOSOTROS</h2><br>
          <p>
          J.R.H. General Services, Corp. es una compañia certificada para ofrecer un servicio completo en la Florida
          de aire acondicionado, ofrecemos servicio de emergencia, mantenimiento planificado, ventas, instalación 
          e ingeniería de diseño. Tanto si se trata de mantenimiento rutinario de CA, como de reparación de
           aire acondicionado o de instalaciones completas de HVAC, nuestros técnicos certificados y 
           experimentados están aquí para usted. 
</p>
<p>
           Nuestra pasión es asegurarnos de que todas sus necesidades de confort estén satisfechas, 
           así que ahorre tiempo, energía y dinero seleccionando cuidadosamente los mejores productos 
           para adaptarse a cualquier proyecto. Nuestro objetivo es proporcionar una experiencia de 
           cliente superior y un gran valor para nuestros clientes.
</p>
 </div>
    </div>