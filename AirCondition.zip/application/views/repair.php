
<div id="detail_services">
    <div class="content">
        <h2 class="h2_services wow fadeInDown">Reparacion</h2>
            <div class="row wow fadeInDown">
                <div id="divimg" class="col-xs-3">
                    <img id="img_details" src="<?php echo base_url(); ?>/assets/images/hairstyle3.jpg" alt="">
                </div>    
                <div class="col-xs-9">
                    <p>
                    Deje que nuestros técnicos salgan a diagnosticar su problema de sistemas, 
                    y le proporcionará una estimación detallada con todas las reparaciones que necesitan 
                    ser hechas. Hacemos una inspección completa de su unidad de condensación al aire libre,
                     así como el evaporador de manipulación de aire. Nuestros tecnicos
                      pueden identificar cualquier problema y proporcionar las reparaciones necesarias necesarias.
                      </p>
                </div>      
            </div>    

        
    </div>
</div>