   
    <div id="about">
       <div class="content wow fadeInDown"> 
          <h2>ABOUT</h2><br>
          <p>
          J.R.H. General Services, Corp. is a certified service provider in Florida
          Air conditioning, we offer emergency service, planned maintenance, sales, installation
          nnd design engineering. Whether it's routine CA maintenance or
           air conditioning or full HVAC installations, our certified technicians and
           experienced are here for you.
</p>
<p>
Our passion is to ensure that all your comfort needs are met,
so save time, energy and money by carefully selecting the best products
to suit any project. Our goal is to provide a
superior customer and great value for our customers.
</p>
 </div>
    </div>