
<div id="detail_services">
    <div class="content">
        <h2 class="h2_services wow fadeInDown">Repair</h2>
            <div class="row wow fadeInDown">
                <div id="divimg" class="col-xs-3">
                    <img id="img_details" src="<?php echo base_url(); ?>/assets/images/hairstyle3.jpg" alt="">
                </div>    
                <div class="col-xs-9">
                    <p>
                    Let our technicians go to diagnose your system problem, and provide you with a detailed
                     estimate with all the repairs you need be made. We do a complete inspection of your 
                     outdoor condensing unit, as well as the air-handling evaporator. Our technicians
                      can identify any problems and provide the necessary repairs needed.
                      </p>
                </div>      
            </div>    

        
    </div>
</div>