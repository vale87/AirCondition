<div id="myCarousel" class="carousel slide carousel-fade" data-ride="carousel">


    <!-- Carousel items -->
    <div class="carousel-inner">

      <!-- Slide 1 : Active -->
      <div class="item active">
        <img src="https://modernize.com/wp-content/uploads/2015/10/amana-hvac.jpg" alt="">
        <div class="carousel-caption black">
          <h2>$1,799</h2>
          <h3>Instalacion Goodman de 3tns con 14 SEER</h3>          
          <p>10 Años de Garantia</p>
        </div><!-- /.carousel-caption -->
      </div><!-- /Slide1 -->

      <!-- Slide 4 -->
      <div class="item ">
        <img src="https://hvacdealers.com/wp-content/uploads/2015/07/Air-Conditioning-Cost-1024x768.jpg" alt="">
        <div class="carousel-caption black">
          <h2>Ahorre con nosotros</h2>
          <h3>Tenemos los mejores precio en todo miami</h3>  
          <p></p>
        </div><!-- /.carousel-caption -->
      </div><!-- /Slide4 -->

      <!-- Slide 2 -->
      <div class="item ">
        <img src="http://integrityairpros.com/wp-content/uploads/2016/11/hvac-service-jasper-1.jpg" alt="">
        <div class="carousel-caption black">
          <h2>$1,699</h2>
          <h3>Instalacion Rheem de 2tns con 14 SEER</h3>  
          <p>10 Años de Garantia</p>
        </div><!-- /.carousel-caption -->
      </div><!-- /Slide2 -->

      <!-- Slide 3 -->
      <div class="item ">
        <img src="http://sketchqatar.com/wp-content/uploads/2015/09/Duct-Cleaning-page.jpg" alt="">
        <div class="carousel-caption black">
          <h2>$150</h2>
          <h3>Limpieza de coil</h3>  
          <p></p>
        </div><!-- /.carousel-caption -->
      </div><!-- /Slide3 -->



    </div><!-- /.carousel-inner -->

  </div><!-- /#myCarousel -->