	
	</div>
	
	<div id="footer">
		<div class="content">
			<h2>CONTACTENOS 24/7</h2>
			<div class="row between-xs">
				<div class="col-xs-6">
					<h3>LLAMANOS</H3>
						<h3>Ventas: <span><?=$contact->phone?></span></h3>
				</div>
		
				<div class="col-xs-2">
					<h3>AREAS</H3>
					<ul>
						<li>Miami</li>
						<li>Fort Lauderdale</li>
						<li>Key West</li>
						<li>West Palm Beach</li>
					</ul>
				</div>
			</div>
				<div class="social hide">
					<a href="" id="facebook">facebook</a>
					<a href="" id="twitter">twitter</a>
					<a href="" id="instagram">instagram</a>
					<a href="" id="googleplus">googleplus</a>
				</div>
				<div>
				</div>
			</div>
		</div>
	</div>


</body>
</html>