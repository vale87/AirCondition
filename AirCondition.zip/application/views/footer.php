	<div id="footer">
		<div class="content">
			<h2>CONTACT US 24/7</h2>
			<div class="row">
				<div class="col-xs">
					<h3>CALL US</H3>
						<p>1-800-000-0000</p>
				</div>
				<div class="col-xs">
					<h3>EMAIL US</H3>
						<p>info@mysuite.com</p>
				</div>
				<div class="col-xs">
					<h3>AREAS COVERED</H3>
					<ul>
						<li>Brooklyn</li>
						<li>Hoboken</li>
						<li>Manhattan</li>
						<li>Queens</li>
						<li>Jersey City</li>
						<li>Harlem</li>
					</ul>
				</div>
				<div class="col-xs">
					<a href="" id="facebook">facebook</a>
				</div>
			</div>
		</div>
	</div>
</body>
</html>