<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class index extends CI_Controller {
   
    function __construct()
    {
       parent::__construct();
    }
   
    public function index()
    {
		  $this->load->view("header");
          $this->load->view("index");
          $this->load->view("footer");
    }
    public function about()
    {
		  $this->load->view("header");
          $this->load->view("about");
          $this->load->view("footer");
    }
    public function contact()
    {
		  $this->load->view("header");
          $this->load->view("contact");
          $this->load->view("footer");
    }
 
}