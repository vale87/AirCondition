<?php
namespace App\Core;
defined("APPPATH") OR die("Access denied");


class Model
{
    public function __construct()
    {

    }
}
