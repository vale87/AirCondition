<?php
namespace Core;
defined("APPPATH") OR die("Access denied");


class Controller
{
    public function __construct()
    {

    }
}
